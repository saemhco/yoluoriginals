<?php

return [
    'name'   => 'Categories',
    'create' => 'New category',
    'edit'   => 'Edit category',
];
