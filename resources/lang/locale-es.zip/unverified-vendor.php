<?php

return [
    'name'   => 'Unverified vendors',
    'verify' => 'Verify vendor',
    'forms'  => [
        'email'              => 'Email',
        'store_name'         => 'Store name',
        'store_phone'        => 'Store phone',
        'confirmation_alert' => 'Are you sure to verify this vendor?',
        'verify_vendor'      => 'Verify vendor',
    ],
];
