<?php

return [
    'name'              => 'Product labels',
    'create'            => 'New product label',
    'edit'              => 'Edit product label',
    'color'             => 'Color',
    'color_placeholder' => 'Example: #f0f0f0',
];
