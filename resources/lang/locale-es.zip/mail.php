<?php

return [
    'send-fail' => 'Send email failed',
];
