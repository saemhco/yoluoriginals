<?php

return [
    'select' => '-- Select --',
    'blog_page_id' => 'Blog page',
];
